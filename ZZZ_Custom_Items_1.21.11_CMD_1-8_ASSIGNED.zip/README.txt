ZZZ Custom Items - Minecraft 1.21.11

Mapowanie Custom Model Data (komponent floats):
1 - feather (piorko)
2 - diamond_sword (diamentowy miecz)
3 - crossbow (kusza)
4 - diamond_pickaxe (diamentowy kilof)
5 - trident (trojzab)
6 - iron_sword (zelazny miecz)
7 - goat_horn (rog kozy)
8 - netherite_sword (netheritowy miecz)

Kazdy model ma parent minecraft:item/handheld, oprocz modelu 3, ktory uzywa minecraft:item/crossbow.

Komendy testowe (Minecraft 1.21.11):
/give @p minecraft:feather[minecraft:custom_model_data={floats:[1]}] 1
/give @p minecraft:diamond_sword[minecraft:custom_model_data={floats:[2]}] 1
/give @p minecraft:crossbow[minecraft:custom_model_data={floats:[3]}] 1
/give @p minecraft:diamond_pickaxe[minecraft:custom_model_data={floats:[4]}] 1
/give @p minecraft:trident[minecraft:custom_model_data={floats:[5]}] 1
/give @p minecraft:iron_sword[minecraft:custom_model_data={floats:[6]}] 1
/give @p minecraft:goat_horn[minecraft:custom_model_data={floats:[7]}] 1
/give @p minecraft:netherite_sword[minecraft:custom_model_data={floats:[8]}] 1
